# CHANGELOG.md

## 1.0.0 (Nov 6, 2018)

First release
